const connectDB = require("./db/connect");
const authenticateUser = require("./authenticate/authentication");
const aws = require('aws-sdk');
const Product = require("./models/Product");
const CustomError = require('./errors/error')

const s3 = new aws.S3({
    region: "us-east-1",
    accessKeyId: "AKIA5LIZGTKRJNXZH4NW",
    secretAccessKey: "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",
    signatureVersion: 'v4'
  });

const deleteImages = async (id) => {

    const product = await Product.findOne({_id: id});
  
    if (!product){
        throw new CustomError.NotFoundError("Product Not Found");
    }
    
    /*for (const image of product.image){

        await s3.deleteObject({
            Bucket:"e-commerce-api",
            Key: image.key
        }).promise();
    }*/

    await s3.deleteObject({
        Bucket:"e-commerce-api",
        Key: "product-images/Screenshot (734).png"
    }).promise();

    product.image = [];
    product.save(); 
}

exports.handler = async (event) => {

    try { 

        await connectDB(process.env.MONGO_URL);

        /*const userInfo = authenticateUser(event.params.headers.authorization);*/

        await deleteImages(event.params.path.id);

        const response = {
            statusCode: 200,
            body: JSON.stringify("Success")
        };

        return response

    }
    catch(error){
        throw error;
    }
};
